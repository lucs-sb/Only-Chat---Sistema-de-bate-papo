package onlychat.api;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OnlyChatApplicationTests {

	@Test
	void contextLoads() {
	}

}
