package onlychat.api;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OnlyChatApplication {

	public static void main(String[] args) {
		SpringApplication.run(OnlyChatApplication.class, args);
	}

}
